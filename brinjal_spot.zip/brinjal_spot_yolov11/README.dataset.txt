# SpudScan > 2024-05-07 2:34pm
https://universe.roboflow.com/prarthana-pyqtt/spudscan

Provided by a Roboflow user
License: CC BY 4.0

